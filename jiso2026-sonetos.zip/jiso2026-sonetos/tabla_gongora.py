#!/usr/bin/env python3
"""
Genera tabla_gongora.csv: los sonetos de Góngora del corpus, con el título de la
edición y el primer verso, para clasificarlos a mano.

Uso:
    python tabla_gongora.py --corpus corpus [--por-soneto por_soneto_surprisal_X.csv ...]

Después, abre el CSV y rellena dos columnas:
    tipo       lirico | circunstancial | burlesco   (u otras categorías; según tu lectura,
               no solo según el título: circunstancial = dedicatorias, a personajes, epitafios)
    canonico   si | (vacío)        (soneto muy antologado/conocido: posible memorización)
y úsalo con analisis_surprisal.py (--tabla ... --separar-tipos / --sin-canonicos).
"""
import argparse
import csv
import re
from pathlib import Path

from surprisal_sonetos import leer_soneto


def num(f):
    return int(re.search(r"(\d+)$", f.stem).group(1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--por-soneto", nargs="*", default=[], help="CSV por_soneto_* de cada modelo (opcional)")
    ap.add_argument("--out", default="tabla_gongora.csv")
    a = ap.parse_args()

    res = {}
    for p in a.por_soneto:
        nombre = "residuo_" + Path(p).stem.replace("por_soneto_surprisal_", "")
        for r in csv.DictReader(open(p, encoding="utf8")):
            res.setdefault(nombre, {})[r["soneto"]] = r["residuo_medio"]

    ficheros = sorted((Path(a.corpus) / "Gongora").glob("*.xml"), key=num)
    cols = ["soneto", "titulo_edicion", "primer_verso", "tipo", "canonico"] + list(res)
    with open(a.out, "w", newline="", encoding="utf8") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for f in ficheros:
            titulo, versos = leer_soneto(f)
            w.writerow([f.stem, titulo, versos[0] if versos else "", "", ""] + [res[c].get(f.stem, "") for c in res])
    print(f"{len(ficheros)} sonetos de Góngora escritos en {a.out}")


if __name__ == "__main__":
    main()
