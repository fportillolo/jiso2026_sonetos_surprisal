# ¿Cuánto sorprende un soneto del Siglo de Oro?
Una lectura computacional de Góngora, Quevedo y Lope · JISO 2026 (Pamplona, 14-15 de diciembre de 2026)

Surprisal por palabra (−log₂ P(palabra | contexto), en bits) calculada con modelos de lenguaje sobre el
[Corpus de sonetos del Siglo de Oro (ADSO)](https://github.com/bncolorado/CorpusSonetosSigloDeOro)
(Navarro-Colorado et al., Universidad de Alicante), comparada entre autores tras controlar frecuencia léxica y longitud.

## Resultado principal (115 sonetos por autor; Salamandra-2B | Qwen2.5-3B)
| | Góngora | Quevedo | Lope |
|---|---|---|---|
| Bits por palabra | 9,99 \| 11,02 | 9,45 \| 10,42 | 9,02 \| 10,04 |
| Residuo (frecuencia + longitud) | +0,30 \| +0,30 | −0,05 \| −0,09 | −0,21 \| −0,18 |

Góngora − Quevedo: +0,35 [+0,18; +0,53] \| +0,39 [+0,17; +0,62]. Góngora − Lope: +0,51 [+0,34; +0,69] \| +0,48 [+0,27; +0,70].
Por tipo de soneto de Góngora (residuo): burlesco +0,60 \| +0,65; circunstancial +0,48 \| +0,51; lírico −0,15 \| −0,21.
El lírico no se distingue de Quevedo ni de Lope (todos los intervalos incluyen el cero).

**Límites.** La clasificación por tipo (`tabla_gongora.csv`) la hizo Claude (Anthropic) a partir de título, primer verso y lectura; no es ciega y está pendiente de revisión por un especialista. Quevedo y Lope no están clasificados por tipo, por lo que la comparación no es pareada. No hay corrección por comparaciones múltiples. No se afirma nada sobre sintaxis (hipérbaton).

## Archivos
| Archivo | Qué hace |
|---|---|
| `surprisal_sonetos.py` | Muestrea N sonetos por autor (semilla fija), puntúa cada palabra con un modelo causal y escribe un CSV con una fila por palabra. |
| `analisis_surprisal.py` | Medias por autor (sobre medias de soneto), residuos de `bits ~ zipf + longitud`, palabras gramaticales, intervalos bootstrap al 95 %. Opciones: `--tabla`, `--separar-tipos`, `--sin-canonicos`, `--desde-verso 2`. |
| `tabla_gongora.py` / `tabla_gongora.csv` | Los 115 sonetos de Góngora con título de la edición, primer verso, `tipo` (burlesco/lirico/circunstancial), `confianza` y `canonico`. |
| `jiso2026_surprisal.ipynb` | Cuaderno de Colab (GPU T4) que ejecuta todo con los dos modelos. |
| `results_piloto_60sonetos/` | Salidas de la ejecución piloto de 60 sonetos por autor. Las cifras de arriba son de la ejecución de 115; esos CSV no están aquí (añádelos de tu Colab). |

## Reproducir
```
pip install -r requirements.txt
git clone https://github.com/bncolorado/CorpusSonetosSigloDeOro corpus
python surprisal_sonetos.py --corpus corpus --n 115 --model BSC-LT/salamandra-2b --out surprisal_salamandra-2b.csv
python analisis_surprisal.py surprisal_salamandra-2b.csv
```
`--selftest` comprueba el parseo y el alineamiento sin cargar ningún modelo. Un modelo de 2B parámetros necesita GPU (Colab) o más de 8 GB de RAM.

## Notas de método
- Surprisal de una palabra = suma de la de sus fragmentos (tokens); cada soneto se puntúa como un único texto, así que el primer verso no tiene contexto y puntúa más alto.
- Frecuencia: escala Zipf de `wordfreq` (español). Unidad de análisis: el soneto; bootstrap de 5.000 remuestreos.
- Los modelos pueden haber visto estos textos (memorización); se atenúa quitando 10 sonetos muy conocidos, sin descartarla.
- El corpus no se redistribuye aquí; respeta su licencia y cita a Navarro-Colorado et al. (2016, LREC).

## Cita
Navarro, B., Ribes Lafoz, M. y Sánchez, N. (2016). Metrical annotation of a large corpus of Spanish sonnets. LREC 2016, 4360–4364.
