#!/usr/bin/env python3
"""
Prueba piloto: surprisal por palabra en sonetos del Siglo de Oro.

Corpus: https://github.com/bncolorado/CorpusSonetosSigloDeOro  (clonar antes)

Uso básico (portátil o Colab):
    pip install torch transformers wordfreq
    git clone https://github.com/bncolorado/CorpusSonetosSigloDeOro corpus
    python surprisal_sonetos.py --corpus corpus --n 20 --model BSC-LT/salamandra-2b

Comprobar solo el parseo y el alineamiento, sin modelo ni torch:
    python surprisal_sonetos.py --corpus corpus --n 5 --selftest

Salida:
    surprisal_palabras.csv   una fila por palabra (autor, soneto, verso, palabra, bits, ...)
    resumen en pantalla      media por autor, calculada sobre medias de soneto
"""
import argparse
import csv
import math
import random
import re
import statistics as st
import xml.etree.ElementTree as ET
from pathlib import Path

NS = {"t": "http://www.tei-c.org/ns/1.0"}
# Carpetas del corpus que se comparan (Lope está dividido en dos).
AUTORES = {
    "Gongora": ["Gongora"],
    "Quevedo": ["Quevedo"],
    "Lope": ["LopeDeVega_1", "LopeDeVega_2"],
}


# ---------------------------------------------------------------- corpus
def leer_soneto(path):
    """Devuelve (titulo, [versos]) de un fichero TEI del corpus."""
    root = ET.parse(path).getroot()
    titulo = (root.findtext(".//t:body/t:head/t:title", default="", namespaces=NS) or "").strip()
    versos = [("".join(l.itertext())).strip() for l in root.iterfind(".//t:l", NS)]
    return titulo, [v for v in versos if v]


def muestrear(corpus, n, seed):
    rng = random.Random(seed)
    raiz = Path(corpus).expanduser().resolve()
    if not raiz.is_dir():
        raise SystemExit(
            f"La carpeta del corpus no existe: {raiz}\n"
            f"Estás ejecutando desde: {Path.cwd()}\n"
            "Pasa la ruta correcta con --corpus (puede ser absoluta)."
        )
    out = {}
    for autor, carpetas in AUTORES.items():
        ficheros = sorted(f for c in carpetas for f in (raiz / c).glob("*.xml"))
        if not ficheros:
            contenido = sorted(x.name for x in raiz.iterdir())[:10]
            raise SystemExit(
                f"No encuentro sonetos de {autor} en {raiz}\n"
                f"Esperaba carpetas como {carpetas} con ficheros .xml dentro.\n"
                f"Lo que hay en esa carpeta: {contenido}"
            )
        out[autor] = rng.sample(ficheros, min(n, len(ficheros)))
    return out


# ---------------------------------------------------- alineamiento a palabras
def tokens_a_palabras(texto, tokens):
    """
    tokens: lista de (inicio_car, fin_car, bits) por token del modelo.
    Suma los bits de los tokens que caen dentro de cada palabra (separada por
    espacios). Los tokens que solo son espacio/salto de línea se ignoran.
    Devuelve [(inicio, fin, bits, n_tokens)] por palabra.
    """
    palabras = [(m.start(), m.end()) for m in re.finditer(r"\S+", texto)]
    acum = [[s, e, 0.0, 0] for s, e in palabras]
    for s, e, bits in tokens:
        while s < e and texto[s].isspace():  # algunos tokenizadores incluyen el espacio previo
            s += 1
        if s >= e:
            continue
        for w in acum:
            if w[0] <= s < w[1]:
                w[2] += bits
                w[3] += 1
                break
    return [tuple(w) for w in acum]


# ---------------------------------------------------------------- modelos
def cargar_modelo(nombre):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(nombre)
    if not tok.is_fast:
        raise SystemExit("Hace falta un tokenizador 'fast' (para los offsets de caracteres).")
    if torch.cuda.is_available():
        # bf16 nativo solo desde Ampere (capacidad 8.x); en una T4 de Colab se usa fp16.
        dtype = torch.bfloat16 if torch.cuda.get_device_capability()[0] >= 8 else torch.float16
    else:
        dtype = torch.float32
    model = AutoModelForCausalLM.from_pretrained(nombre, torch_dtype=dtype)
    model.eval()
    if torch.cuda.is_available():
        model.to("cuda")

    def puntuar(texto):
        enc = tok(texto, add_special_tokens=False, return_offsets_mapping=True)
        ids = enc["input_ids"]
        offs = enc["offset_mapping"]
        inicio = tok.bos_token_id if tok.bos_token_id is not None else tok.eos_token_id
        ids_in = torch.tensor([[inicio] + ids], device=model.device)
        with torch.no_grad():
            logits = model(ids_in).logits[0, :-1].float()
        logp = torch.log_softmax(logits, dim=-1)
        objetivo = ids_in[0, 1:]
        nll = -logp[torch.arange(len(ids)), objetivo] / math.log(2)  # bits
        return [(o[0], o[1], b) for o, b in zip(offs, nll.tolist())]

    return puntuar


def modelo_falso():
    """Para --selftest: trocea en bloques de 3 caracteres con surprisal aleatoria."""
    rng = random.Random(0)

    def puntuar(texto):
        return [(i, min(i + 3, len(texto)), rng.uniform(1, 12)) for i in range(0, len(texto), 3)]

    return puntuar


# ------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--n", type=int, default=20, help="sonetos por autor")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--model", default="BSC-LT/salamandra-2b")
    ap.add_argument("--out", default="surprisal_palabras.csv")
    ap.add_argument("--selftest", action="store_true", help="sin modelo: solo parseo y alineamiento")
    a = ap.parse_args()

    try:
        from wordfreq import zipf_frequency
    except ImportError:
        zipf_frequency = None
        print("Aviso: sin 'wordfreq' no se añade la frecuencia léxica (pip install wordfreq).")

    puntuar = modelo_falso() if a.selftest else cargar_modelo(a.model)
    muestra = muestrear(a.corpus, a.n, a.seed)

    filas = []
    total = sum(len(v) for v in muestra.values())
    hechos = 0
    for autor, ficheros in muestra.items():
        for f in ficheros:
            hechos += 1
            print(f"[{hechos}/{total}] {autor} - {f.stem}", flush=True)
            titulo, versos = leer_soneto(f)
            texto = "\n".join(versos)
            # Posición de cada verso en el texto, para saber a qué verso pertenece cada palabra.
            limites, pos = [], 0
            for v in versos:
                limites.append((pos, pos + len(v)))
                pos += len(v) + 1
            for ini, fin, bits, ntok in tokens_a_palabras(texto, puntuar(texto)):
                verso = next(i for i, (s, e) in enumerate(limites, 1) if s <= ini < e)
                crudo = texto[ini:fin]
                limpia = re.sub(r"^\W+|\W+$", "", crudo).lower()
                filas.append(
                    {
                        "autor": autor,
                        "soneto": f.stem,
                        "verso": verso,
                        "palabra": crudo,
                        "bits": round(bits, 4),
                        "n_tokens": ntok,
                        "longitud": len(limpia),
                        "zipf": zipf_frequency(limpia, "es") if (zipf_frequency and limpia) else "",
                    }
                )

    with open(a.out, "w", newline="", encoding="utf8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(filas[0]))
        w.writeheader()
        w.writerows(filas)

    sin_tokens = sum(1 for r in filas if r["n_tokens"] == 0)
    if sin_tokens:
        print(f"Aviso: {sin_tokens} de {len(filas)} palabras sin ningún token asignado "
              "(un token cruza varias palabras). Con tokenizadores BPE/SentencePiece normales "
              "debería ser ~0; si es alto, cambia de modelo. Esas filas tienen bits=0.")

    # Resumen: media por soneto -> media y error estándar por autor.
    print(f"\n{len(filas)} palabras escritas en {a.out}"
          + ("  [SELFTEST: los bits son aleatorios]" if a.selftest else f"  (modelo: {a.model})"))
    print(f"{'autor':10} {'sonetos':>8} {'bits/palabra':>13} {'EE':>6}")
    for autor in AUTORES:
        medias = {}
        for r in filas:
            if r["autor"] == autor:
                medias.setdefault(r["soneto"], []).append(r["bits"])
        m = [st.mean(v) for v in medias.values()]
        ee = st.stdev(m) / math.sqrt(len(m)) if len(m) > 1 else float("nan")
        print(f"{autor:10} {len(m):>8} {st.mean(m):>13.2f} {ee:>6.2f}")


if __name__ == "__main__":
    main()
