#!/usr/bin/env python3
"""
Análisis del CSV que genera surprisal_sonetos.py.

Uso:
    python analisis_surprisal.py surprisal_palabras.csv

Qué hace:
  1. Media bruta de bits/palabra por autor (sobre medias de soneto).
  2. Media tras quitar lo que explican la frecuencia léxica (zipf) y la longitud
     de la palabra: residuos de bits ~ zipf + longitud.
  3. Lo mismo solo con palabras gramaticales (artículos, preposiciones,
     conjunciones, pronombres átonos), donde el léxico pesa mucho menos.
  4. Diferencias entre autores con intervalo de confianza al 95 % (bootstrap
     sobre sonetos) para las tres medidas.
  5. Escribe por_soneto_<nombre del csv>.csv con las medias de cada soneto, para revisar a mano
     cuáles son burlescos y cuáles serios.

Opciones (opcionales), para la segunda fase, con tabla_gongora.csv ya rellenado
(columnas "tipo": lirico / circunstancial / burlesco, o las categorías que uses, y
"canonico": si/no):
    --tabla tabla_gongora.csv --separar-tipos    Góngora se divide en Gongora_<tipo>
    --tabla tabla_gongora.csv --sin-canonicos    excluye los sonetos marcados canonico=si

Comprobación de robustez recomendada (la usa el gráfico del informe):
    python analisis_surprisal.py surprisal_X.csv --desde-verso 2

Solo necesita numpy.
"""
import argparse
import csv
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

GRAMATICALES = set(
    """el la los las un una unos unas al del de a en con por para sin sobre entre
    hasta desde y e o u ni que pero mas más sino si sí no se me te le les lo nos os
    mi tu su mis tus sus como cuando donde quien cual""".split()
)
RNG = np.random.default_rng(1)


def limpiar(p):
    return re.sub(r"^\W+|\W+$", "", p).lower()


def leer(path):
    filas = []
    for r in csv.DictReader(open(path, encoding="utf8")):
        if int(r["n_tokens"]) == 0 or r["zipf"] == "" or not limpiar(r["palabra"]):
            continue  # sin tokens asignados, o sin palabra real (solo puntuación)
        filas.append(
            {
                "autor": r["autor"],
                "soneto": r["soneto"],
                "palabra": limpiar(r["palabra"]),
                "bits": float(r["bits"]),
                "zipf": float(r["zipf"]),
                "long": float(r["longitud"]),
                "verso": int(r["verso"]),
            }
        )
    return filas


def residuos(filas):
    """Residuos de bits ~ 1 + zipf + longitud (mínimos cuadrados)."""
    X = np.array([[1.0, f["zipf"], f["long"]] for f in filas])
    y = np.array([f["bits"] for f in filas])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    print(f"Regresión: bits = {beta[0]:.2f} {beta[1]:+.2f}*zipf {beta[2]:+.2f}*longitud")
    return y - X @ beta


def medias_por_soneto(filas, valores):
    acum = defaultdict(list)
    for f, v in zip(filas, valores):
        acum[(f["autor"], f["soneto"])].append(v)
    return {k: float(np.mean(v)) for k, v in acum.items()}


def por_autor(medias):
    out = defaultdict(list)
    for (autor, _), m in medias.items():
        out[autor].append(m)
    return {a: np.array(v) for a, v in out.items()}


def informe(titulo, medias):
    ma = por_autor(medias)
    print(f"\n== {titulo} ==")
    print(f"{'autor':10} {'sonetos':>8} {'media':>8} {'EE':>6}")
    for a, v in ma.items():
        ee = v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else float("nan")
        print(f"{a:10} {len(v):>8} {v.mean():>8.2f} {ee:>6.2f}")
    autores = list(ma)
    for i in range(len(autores)):
        for j in range(i + 1, len(autores)):
            a, b = autores[i], autores[j]
            boot = [
                RNG.choice(ma[a], len(ma[a])).mean() - RNG.choice(ma[b], len(ma[b])).mean()
                for _ in range(5000)
            ]
            lo, hi = np.percentile(boot, [2.5, 97.5])
            dif = ma[a].mean() - ma[b].mean()
            marca = "  <- el IC no incluye 0" if lo > 0 or hi < 0 else ""
            print(f"  {a} - {b}: {dif:+.2f}  IC95% [{lo:+.2f}, {hi:+.2f}]{marca}")


def aplicar_tabla(filas, ruta, separar, sin_canonicos):
    """Usa la tabla manual de Góngora para separar serios/burlescos o excluir canónicos."""
    tabla = {r["soneto"]: r for r in csv.DictReader(open(ruta, encoding="utf8"))}
    antes = len({f["soneto"] for f in filas})
    if sin_canonicos:
        filas = [f for f in filas if tabla.get(f["soneto"], {}).get("canonico", "").strip().lower() not in ("si", "sí", "s")]
        print(f"Excluidos canónicos: {antes - len({f['soneto'] for f in filas})} sonetos")
    if separar:
        sin_clasificar = set()
        for f in filas:
            if f["autor"] == "Gongora":
                tipo = re.sub(r"\s+", "_", tabla.get(f["soneto"], {}).get("tipo", "").strip().lower())
                if tipo:
                    f["autor"] = f"Gongora_{tipo}"
                else:
                    sin_clasificar.add(f["soneto"])
        if sin_clasificar:
            print(f"Aviso: {len(sin_clasificar)} sonetos de Góngora sin 'tipo' siguen como 'Gongora'.")
    return filas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--tabla", help="tabla_gongora.csv rellenada a mano")
    ap.add_argument("--separar-tipos", action="store_true")
    ap.add_argument("--sin-canonicos", action="store_true")
    ap.add_argument("--desde-verso", type=int, default=1,
                    help="ignora los versos anteriores a este (2 = sin el primer verso, que siempre "
                         "sorprende más porque el modelo aún no tiene contexto)")
    a = ap.parse_args()
    filas = leer(a.csv)
    if a.desde_verso > 1:
        filas = [f for f in filas if f["verso"] >= a.desde_verso]
        print(f"Solo versos {a.desde_verso}-14")
    if a.tabla and (a.separar_tipos or a.sin_canonicos):
        filas = aplicar_tabla(filas, a.tabla, a.separar_tipos, a.sin_canonicos)
    elif a.separar_tipos or a.sin_canonicos:
        raise SystemExit("Esas opciones necesitan --tabla tabla_gongora.csv")
    print(f"{len(filas)} palabras usadas")

    bits = [f["bits"] for f in filas]
    informe("1. Bruto (bits/palabra)", medias_por_soneto(filas, bits))

    res = residuos(filas)
    informe("2. Residuos tras frecuencia y longitud (0 = lo esperable por la rareza de la palabra)",
            medias_por_soneto(filas, res))

    idx = [i for i, f in enumerate(filas) if f["palabra"] in GRAMATICALES]
    sub = [filas[i] for i in idx]
    informe(f"3. Solo palabras gramaticales ({len(sub)} palabras, bits brutos)",
            medias_por_soneto(sub, [f["bits"] for f in sub]))

    brutas = medias_por_soneto(filas, bits)
    resid = medias_por_soneto(filas, res)
    sufijo = (("_v%d" % a.desde_verso) if a.desde_verso > 1 else "") + ("_tipos" if a.separar_tipos else "") + ("_sincanon" if a.sin_canonicos else "")
    salida = f"por_soneto_{Path(a.csv).stem}{sufijo}.csv"
    with open(salida, "w", newline="", encoding="utf8") as fh:
        w = csv.writer(fh)
        w.writerow(["autor", "soneto", "bits_medios", "residuo_medio"])
        for k in sorted(brutas, key=lambda k: -brutas[k]):
            w.writerow([k[0], k[1], round(brutas[k], 3), round(resid[k], 3)])
    print(f"\nEscrito {salida} (ordenado de más a menos sorprendente).")


if __name__ == "__main__":
    main()
